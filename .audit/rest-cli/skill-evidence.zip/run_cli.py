import json, os, pathlib, re, subprocess, sys
MANIFEST=pathlib.Path('/var/folders/91/b4gh134x6zdfdw1x9kwd0rrc0000gn/T/artifacts-cli-forward-5dgUv8/connection.json')
BASE=pathlib.Path(__file__).parent
CLI='/tmp/artifacts-rest-cli-implementation/dist/packages/forward-consumer/node_modules/.bin/artifacts'
def run(label,args,print_result=True):
    manifest=json.loads(MANIFEST.read_text())
    env=os.environ.copy()
    env.update({str(k):str(v) for k,v in manifest['env'].items()})
    env['ARTIFACTS_STATE_DIR']=str(BASE/'state')
    result=subprocess.run([CLI,*args],env=env,capture_output=True,text=True)
    secrets=[str(v) for k,v in manifest['env'].items() if any(x in k.lower() for x in ['token','password','secret','session'])]
    def clean(v):
        if isinstance(v,dict):
            return {k:('[REDACTED]' if any(s in k.lower() for s in ['token','password','secret','session']) else clean(x)) for k,x in v.items()}
        if isinstance(v,list):return [clean(x) for x in v]
        if isinstance(v,str):
            for s in secrets:
                if s:v=v.replace(s,'[REDACTED]')
            return v
        return v
    try: out=json.loads(result.stdout)
    except json.JSONDecodeError: out=result.stdout
    record=clean({'args':args,'exitCode':result.returncode,'stdout':out,'stderr':result.stderr})
    (BASE/'outputs'/f'{label}.json').write_text(json.dumps(record,indent=2)+'\n')
    if print_result:print(json.dumps(record,indent=2))
    return result.returncode,out,record
if __name__=='__main__':
    code,_,_=run(sys.argv[1],sys.argv[2:]);sys.exit(code)
